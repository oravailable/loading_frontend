package repository

type Like struct { UserID int }

type Containership struct {
	ID int
	Name string
	Description string
	Port string
	CapacityTEU int
	DraftM float64
	ImageKey string
	VideoKey string
	Status string
	Likes []Like
}

var containerships = []Containership{
	{1,"MSC AURORA","Крупный контейнеровоз для международных грузовых перевозок.","Новороссийск",13500,16.2,"msc-aurora.jpg","msc-aurora.mp4","published",[]Like{{1},{2},{3},{4},{5},{6}}},
	{2,"ONE SPIRIT","Современный контейнеровоз для перевозки контейнерных грузов.","Владивосток",13768,16.0,"one-spirit.jpg","one-spirit.mp4","published",[]Like{{1},{2},{3},{4}}},
	{3,"ONE TRIUMPH","Большой контейнеровоз для работы на международных маршрутах.","Гамбург",20170,16.5,"one-triumph.jpg","one-triumph.mp4","published",[]Like{{1},{2},{3},{4},{5}}},
	{4,"CMA CGM OCEAN","Контейнеровоз большой вместимости.","Новороссийск",18000,16.4,"cma-cgm-ocean.jpg","cma-cgm-ocean.mp4","published",[]Like{{1},{2},{3}}},
	{5,"DRAFT SHIP","Черновая запись для страницы добавления.","Новороссийск",12000,15.8,"draft-ship.jpg","draft-ship.mp4","draft",nil},
}

func Published() []Containership {
	var result []Containership
	for _, s := range containerships {
		if s.Status == "published" { result = append(result, s) }
	}
	return result
}

func ByID(id int) (Containership, bool) {
	for _, s := range containerships {
		if s.ID == id && s.Status != "deleted" { return s, true }
	}
	return Containership{}, false
}

func Draft() (Containership, bool) {
	for _, s := range containerships {
		if s.Status == "draft" { return s, true }
	}
	return Containership{}, false
}

func FilterByCapacity(min, max int) []Containership {
	var result []Containership
	for _, s := range Published() {
		if min > 0 && s.CapacityTEU < min { continue }
		if max > 0 && s.CapacityTEU > max { continue }
		result = append(result, s)
	}
	return result
}
