package server

import (
	"html/template"
	"net/http"
	"container-loading/internal/app/handler"
	"github.com/gin-gonic/gin"
)

func New() *gin.Engine {
	r := gin.New()
	r.Use(gin.Logger(), gin.Recovery())
	r.SetFuncMap(template.FuncMap{})
	r.LoadHTMLGlob("templates/*.html")
	r.Static("/static", "./static")

	h := handler.New()
	r.GET("/feed/:id", h.GetFeed)
	r.GET("/add", h.GetAdd)
	r.GET("/containerships", h.GetContainerships)

	r.GET("/", func(c *gin.Context) {
		c.Redirect(http.StatusTemporaryRedirect, "/feed/1")
	})
	return r
}
