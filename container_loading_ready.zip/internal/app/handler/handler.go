package handler

import (
	"net/http"
	"strconv"
	"container-loading/internal/app/repository"
	"github.com/gin-gonic/gin"
)

const minioBaseURL = "http://localhost:9000/ships/"

type Handler struct{}

type PageData struct {
	Ship repository.Containership
	Ships []repository.Containership
	ImageURL string
	VideoURL string
	MinCapacity int
	MaxCapacity int
	HasNext bool
	NextURL string
}

func New() *Handler { return &Handler{} }

func mediaURL(key string) string { return minioBaseURL + key }

func (h *Handler) GetFeed(c *gin.Context) {
	id, err := strconv.Atoi(c.Param("id"))
	if err != nil { c.String(http.StatusBadRequest, "Некорректный ID судна"); return }

	ship, ok := repository.ByID(id)
	if !ok { c.String(http.StatusNotFound, "Судно не найдено"); return }

	ships := repository.Published()
	if c.Query("next") == "true" {
		for i, s := range ships {
			if s.ID == id && i+1 < len(ships) { ship = ships[i+1]; break }
		}
	}

	hasNext := false
	nextURL := ""
	for i, s := range ships {
		if s.ID == ship.ID && i+1 < len(ships) {
			hasNext = true
			nextURL = "/feed/" + strconv.Itoa(s.ID) + "?next=true"
			break
		}
	}

	c.HTML(http.StatusOK, "feed.html", PageData{
		Ship: ship, ImageURL: mediaURL(ship.ImageKey), VideoURL: mediaURL(ship.VideoKey),
		HasNext: hasNext, NextURL: nextURL,
	})
}

func (h *Handler) GetAdd(c *gin.Context) {
	ship, ok := repository.Draft()
	if !ok { c.String(http.StatusNotFound, "Черновик не найден"); return }
	c.HTML(http.StatusOK, "add.html", PageData{
		Ship: ship, ImageURL: mediaURL(ship.ImageKey), VideoURL: mediaURL(ship.VideoKey),
	})
}

func (h *Handler) GetContainerships(c *gin.Context) {
	min, _ := strconv.Atoi(c.DefaultQuery("min", "0"))
	max, _ := strconv.Atoi(c.DefaultQuery("max", "0"))
	c.HTML(http.StatusOK, "containerships.html", PageData{
		Ships: repository.FilterByCapacity(min, max), MinCapacity: min, MaxCapacity: max,
	})
}
