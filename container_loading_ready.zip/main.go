package main

import (
	"log"
	"container-loading/internal/app/server"
)

func main() {
	log.Println("Container Loading application")
	log.Println("Server: http://localhost:8080")
	if err := server.New().Run(":8080"); err != nil { log.Fatal(err) }
}
