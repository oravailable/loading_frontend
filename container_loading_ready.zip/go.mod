module container-loading

go 1.23

require github.com/gin-gonic/gin v1.10.0
